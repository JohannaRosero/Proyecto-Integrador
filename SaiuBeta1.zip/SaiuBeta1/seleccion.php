<?php
	require_once ("conexion.php");
?>
<!DOCTYPE html>
<html class="js" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>SAIU :3</title>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="css/main.css">
    </head>
<body>
<!--Barra superior de contenidos, se muestran en pestanias, mas o menos-->
	<div class="topnav">
		<a href="index.html">Inicio</a>
		<a href="instrucciones.php">Instrucciones</a>
        <a class="active" href="#resultados">Resultados</a>
		<a href="contacto.php">Contacto</a>
		<a href="acerca.php">Acera de</a>
	</div>
    <!--Contenido de la pagina desde aqui-->
	<div style="padding-left:16px">
		<h2>SAIU</h2>
		<p>Descripcion...</p>
	</div>
    <!--Contenedor del drag and drop, la caja para subir los archivos-->
    <div class="container_info" role="main">
    	<div class="box_info">
        	<h1>Seleccion de Genero</h1>
        	<!--los nombres de las variables para enviar los datos de los input text al php que guarda-->
           	<!--los datos en la base son nombre_usuario y correo-->
            <form action="resultados.php" method="post" enctype="multipart/form-data">
            <!--<strong>Marcar todos como: </strong><input type="radio" name="gender" id="gender1" value="Masculino"> Masculino
				<input type="radio" name="gender" id="gender2" value="Femenino"> Femenino
				<input type="radio" name="gender" id="gender3" value="Sin definir">Sin definir<br>-->
            <?php
				$num_chat = $_COOKIE["TestCookie"];
				$cont = 0;
				$sql = $conexion->query("SELECT `nombre`,COUNT(`mensaje`) AS 'num_mens' FROM `".$num_chat."` GROUP BY 			`nombre`;");
				while($res = mysqli_fetch_array($sql)) {
					echo '<p><strong>'.$res[0].'</p></strong><select class="combo_app" name="combo_gender'.$cont.'">
												<option name="Masculino" value="Masculino">Masculino</option>
												<option name="Femenino" value="Femenino">Femenino</option>
												<option name="Sin definir" value="Sin definir">Sin definir</option>
					</select><br>';
					$cont++;
				}
	    	?>
			<p>Cantidad de personas: <input type="text" name="cant_personas" value="<?php echo $cont ?>" readonly size="5"></p>
            <button type="submit" class="box__button">Continuar</button>
            </form>
        </div>
    </div><br></br>
	<div class="container" role="main">
		<footer>
			<p><strong>Universidad de las Fuerzas Armadas ESPE.</strong></p>
		</footer>
	</div>
</body>
</html>
<?php 
require_once("connection.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Highcharts Example</title>

		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<style type="text/css">
${demo.css}
		</style>
		<script type="text/javascript">
$(function () {
    $('#container1').highcharts({
        title: {
            text: 'Reportes Estadisticos Generales',
            x: -20 //center
        },
        subtitle: {
            text: 'Source: Base Datos Chat',
            x: -20
        },
        xAxis: {
            categories: [
            <?php 
            $sql = "SELECT hora, COUNT(*) AS intervencion FROM datos_chat GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($connection,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                '<?php echo date('H',strtotime($registros["hora"])); ?>',
            <?php
            }
            ?>
            ]
        },
        yAxis: {
            title: {
                text: 'Cantidad de mensajes'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
            name: 'Cantidad',
            data: [
            <?php 
            $sql = "SELECT hora, COUNT(*) AS intervencion FROM datos_chat GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($connection,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                <?php echo $registros["intervencion"] ?>,
            <?php
            }
            ?>
            ]
        }]
    });
});
</script>
<script type="text/javascript">
$(function () {
    $('#container').highcharts({
        title: {
            text: 'Reportes Estadisticos Por Usuario',
            x: -20 //center
        },
        subtitle: {
            text: 'Source: Base Datos Chat',
            x: -20
        },
        xAxis: {
            categories: [
            <?php 
            $sql = "SELECT hora, COUNT(*) AS intervencion FROM datos_chat GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($connection,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                '<?php echo date('H',strtotime($registros["hora"])); ?>',
            <?php
            }
            ?>
            ]
        },
        yAxis: {
            title: {
                text: 'Cantidad de mensajes'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [
			<?php
			$sql = "SELECT nombre from datos_chat GROUP BY nombre";
            $result = mysqli_query($connection,$sql);
			$cont = mysqli_num_rows($result);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
				{
					name:'<?php echo $registros["nombre"] ?>',
					data: [
				<?php 
				$sql1 = "SELECT hora, COUNT(*) AS intervencion FROM datos_chat WHERE nombre='".$registros["nombre"]."' GROUP BY hora ORDER BY hora ASC";
				$result1 = mysqli_query($connection,$sql1);
				while ($registros1= mysqli_fetch_array($result1))
				{
				?>
					<?php echo $registros1["intervencion"] ?>,
				<?php
				}
				?>
				]
				<?php
				if($cont>1){
					$cont--;
					?>
					},
				<?php	
				}else{
				?>
				}
				<?php
				}
				
				?>
				
            <?php
            }
            ?>
			

			]
    });
});
		</script>
	</head>
	<body>
<script src="js/highcharts.js"></script>
<script src="js/modules/exporting.js"></script>
<div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

	</body>
</html>

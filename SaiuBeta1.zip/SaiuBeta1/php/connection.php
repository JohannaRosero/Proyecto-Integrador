<?php 
	$connection = mysqli_connect("localhost","root","OscarIN21120","prototipo2");
?>
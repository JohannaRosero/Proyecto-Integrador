<?php
	/*Funcion para comprobar que el archivo fue subido*/
	function existe_archivo() {
		if($_FILES['files']['error'] > 0) {
			$message = "Esto no deberia haber pasado, por favor intentalo mas tarde.";
			echo "<script type='text/javascript'>alert('$message')</script>";
			return false;
		} else {
			return true;
		}
	}
	/*Funcion para comprobar si el archivo subido corresponde a un txt*/
	function archivo_es_txt() {
		if(existe_archivo()) {
			if($_FILES['files']['type'] <> "text/plain") {
				$message = "El archivo subido corresponde a un ".$_FILES['files']['type'].
					" \\npara continuar suba un archivo txt válido.\\nSera redireccionado a la página principal de SAIU";
				$var_msg = "index.html";
				return false;
			} else {
				$nombre = $_FILES['files']['name'];
				echo "Nombre: " . $_FILES['files']['name'] . "<br>";
				echo "Tipo: " . $_FILES['files']['type'] . "<br>";
				echo "Tamaño: " . ($_FILES["files"]["size"] / 1024) . " kB<br>";
				echo "Carpeta temporal: " . $_FILES['files']['tmp_name'];
				echo $nombre;
				$message = "El archivo ingresado es valido.\\nAhora continuaremos con el proceso";
				echo "<script type='text/javascript'>alert('$message');</script>";
				return true;
			}
		} else {
			return false;
		}
	}
	/*Funcion para subir el archivo al servidor*/
	function mover_archivo_carpeta() {
		if(archivo_es_txt()) {
			$cont_archivos = 0;
			$aux = true;
			$nombre = "";
			do {
				$nombre_archivo = "chat".$cont_archivos.".txt";
				if(file_exists("upload_files/".$nombre_archivo)) {
					$aux = false;
				} else {
					move_uploaded_file($_FILES['files']['tmp_name'], "upload_files/".$nombre_archivo);
					$aux = true;
					$nombre = "chat".$cont_archivos;
				}
				$cont_archivos++;
			} while ($aux == false);
			return $nombre;
		} else {
			return $nombre;
		}
	}

	//Funcion para dividir el archivo txt
	function multiexplode ($delimitadores, $argumento) {
		$ready = str_replace($delimitadores, $delimitadores[0], $argumento);
		$launch = explode($delimitadores[0], $ready);
		return $launch;
	}

	//Crear nuevo archivo csv
	function crear_csv() {
		$nombre_archivo = mover_archivo_carpeta();
		$nombre_txt = $nombre_archivo.".txt";
		$nombre_csv = $nombre_archivo.".csv";
		if(strlen($nombre_csv) <> 0) {
			//bloque de código para abrir el txt
			$file = fopen("upload_files/".$nombre_txt, "r") or exit("No se puede abrir en archivo");
			while(!feof($file)) {
				//uso de la funcion para separar
				$linea_chat = fgets($file);
				$exploded_linea = multiexplode(array("/18 ", " - ", ": "), $linea_chat);
				if(count($exploded_linea) == 4) {
					$linea_fecha = $exploded_linea[0];
					$fecha = explode('/', $linea_fecha);
					$fecha_mod = "2018-".$fecha[1]."-".$fecha[0];
					$exploded_linea[4] = "'";
					//Hora hora hora!!!
					$partes = multiexplode(array(":", " "), $exploded_linea[1]);
					if($partes[2] == "PM") {
						$partes[0] += 12;
					}
					$palabras = explode(" ", $exploded_linea[3]);
					$linea_csv = "'".$fecha_mod."'~'".$partes[0].":".$partes[1]."'~'".$exploded_linea[2]."'~'".trim($exploded_linea[3])."'~".(strlen($exploded_linea[3])-1)."~".count($palabras)."\n";
					if($archivo = fopen("csv_files/".$nombre_csv, "a")) {
						if(fwrite($archivo, $linea_csv)) {
						} else {
							echo "Ha habido un problema al crear el archivo"."<br>";
						}
						fclose($archivo);
					}
				}
			}
			echo "<br>"."Se ha ejecutado correctamente"."<br>";
			fclose($file);
			return $nombre_archivo;
		} else {
			return "";
		}
	}

	//Conexion con la base de datos
	include 'conexion.php';
	//Sentencia para agregar el usuario a la tabla
	//aqui usamos los nombres que les dimos a los input text

	$query = "INSERT INTO usuarios (nombre, correo)
           VALUES ('$_POST[nombre_usuario]', '$_POST[correo]')";
	if ($conexion->query($query) === TRUE) {
 		echo "<br />" . "<h2>" . "Usuario registrado Exitosamente!" . "</h2>";
		echo "<h4>" . "Bienvenido: " . $_POST['nombre_usuario'] . "</h4>" . "\n\n";
	} else {
		echo "Error al registrar el usuario." . $query . "<br>" . $conexion->error;
	}
	//Tomar datos del csv y guardarlos en la base de datos

	$nombre_archivo = crear_csv();
	setcookie("TestCookie", $nombre_archivo, time()+300);//Cookie expira en 5 minutos
	$filename = "csv_files/".$nombre_archivo.".csv";
	echo $filename."<br>";
	$info = new SplFileInfo($filename);
	echo $info."<br>";
	$extension = pathinfo($info->getFilename(), PATHINFO_EXTENSION);
	echo $extension."<br>";
 	if($extension == 'csv') {
		$handle = fopen($filename, "r");
		$sql_creacion = "CREATE TABLE `".$nombre_archivo."` (
  							`fecha` date NOT NULL,
							`hora` time NOT NULL,
							`nombre` varchar(50) COLLATE utf8mb4_spanish2_ci NOT NULL,
							`mensaje` varchar(600) COLLATE utf8mb4_spanish2_ci NOT NULL,
							`num_caracteres` int(11) NOT NULL,
							`num_palabras` int(11) NOT NULL
							) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;";
		$conexion->query($sql_creacion);
 		while( ($data = fgetcsv($handle, 1000, "~") ) !== FALSE ) {
			$sql = "INSERT INTO `".$nombre_archivo."`(`fecha`, `hora`, `nombre`, `mensaje`, `num_caracteres`, `num_palabras`) VALUES (
			$data[0],
			$data[1],
			$data[2],
			$data[3],
			$data[4],
			$data[5]
			);";
			$conexion->query($sql);
		}
	    fclose($handle);
	}
	$var_msg = "seleccion.php";
	echo "<script type='text/javascript'>window.location.replace('$var_msg');</script>";
	mysqli_close($conexion);
?>

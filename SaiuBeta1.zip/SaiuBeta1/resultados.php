<!DOCTYPE html>
<head>
	<script>
	window.onload = function(){
		var contenedor = document.getElementById('contenedor_carga');
		contenedor.style.visibility='hidden';
		contenedor.style.opacity = '0';
	}
	</script>
	<script>
window.onload = function(){
	var contenedor = document.getElementById('contenedor_carga');
	contenedor.style.visibility='hidden';
	contenedor.style.opacity = '0';
}
</script>
</head>
<body>
	<div id="contenedor_carga">
		<div id="carga"></div>
		</div>
<?php

	include 'conexion.php';
	for($i = 0; $i < $_POST['cant_personas']; $i++) {
		$query = $_POST['combo_gender'.$i];
		if($query == 'Masculino') {
			$sql = $conexion->query("UPDATE `genero` SET `masculino`=`masculino`+1 WHERE `id`=1;");
		} elseif($query == 'Femenino') {
			$sql = $conexion->query("UPDATE `genero` SET `femenino`=`femenino`+1 WHERE `id`=1;");
		} else {
			$sql = $conexion->query("UPDATE `genero` SET `no_definido`=`no_definido`+1 WHERE `id`=1;");
		}
	}
	$var_msg = "diagramas.php";
	echo "<script type='text/javascript'>window.location.replace('$var_msg');</script>";
?>
</body>
</html>

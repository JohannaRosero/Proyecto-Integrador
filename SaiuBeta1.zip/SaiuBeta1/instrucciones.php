<!DOCTYPE html>
<html class="js" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<title>SAIU Beta</title>
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" href="css/main.css">
</head>
<body>
<!--Barra superior de contenidos, se muestran en pestanias, mas o menos-->
	<div class="topnav">
		<a href="index.html">Inicio</a>
		<a class="active" href="instrucciones.php">Instrucciones</a>
		<a href="contacto.php">Contacto</a>
		<a href="acerca.php">Acera de</a>
	</div>
    <!--Contenido de la pagina desde aqui-->
	<div style="padding-left:16px">
		<h2>SAIU Beta</h2>
		<p>Descripci&#243n...</p>
	</div>
    <!--Contenedor de video sobre las instrucciones-->
	<div class="container" role="main">
		<div class="box has-advanced-upload">
			<p>Aqui instrucciones segun el caso</p>
		</div>
	<footer>
		<p><strong>Universidad de las Fuerzas Armadas ESPE.</strong></p>
	</footer>
</div>
</body>
</html>
<?php
	$host_db = "localhost";
	$user_db = "root";
	$pass_db = "";
	$db_name = "prototipo3";
	$conexion = new mysqli($host_db, $user_db, $pass_db, $db_name);
	if ($conexion->connect_error) {
		$message = "Esto no deberia haber pasado, por favor intentalo mas tarde.";
		$var_msg = "index.html";
		die("<script type='text/javascript'>window.location.replace('$var_msg');</script>");
	}
	$conexion->select_db($db_name);
?>

<?php
	include 'conexion.php';//esto t conecta a la base de datos
?>
<!DOCTYPE html>
<html>
<head>
	<title>SAIU con Highcharts</title>
    <link rel="stylesheet" href="css/main.css">
    <!--Script para diagrama de pastel-->

	<!--Script para nube de palabras-->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
  	<script>
    	zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    	ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
	</script>
    <!--Script para diagrama lineal-->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>


		<script type="text/javascript">
$(function () {
    $('#container5').highcharts({
        title: {
            text: 'Reportes Estadisticos Generales',
            x: -20 //center
        },
        subtitle: {
            text: 'Source: Base Datos Chat',
            x: -20
        },
        xAxis: {
            categories: [
            <?php
			$num_chat = $_COOKIE["TestCookie"];
            $sql = "SELECT hora, COUNT(hora) AS intervencion FROM ".$num_chat." GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($conexion,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                '<?php echo $registros["hora"]; ?>',
            <?php
            }
            ?>
            ]
        },
        yAxis: {
            title: {
                text: 'Cantidad de mensajes'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [{
            name: 'Cantidad',
            data: [
            <?php
            $sql = "SELECT hora, COUNT(*) AS intervencion FROM ".$num_chat." GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($conexion,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                <?php echo $registros["intervencion"] ?>,
            <?php
            }
            ?>
            ]
        }]
    });
});
</script>
<script type="text/javascript">
$(function () {
    $('#container6').highcharts({
        title: {
            text: 'Reportes Estadisticos Por Usuario',
            x: -20 //center
        },
        subtitle: {
            text: 'Source: Base Datos Chat',
            x: -20
        },
        xAxis: {
            categories: [
            <?php
			$num_chat = $_COOKIE["TestCookie"];
            $sql = "SELECT hora, COUNT(*) AS intervencion FROM ".$num_chat." GROUP BY hora ORDER BY hora ASC";
            $result = mysqli_query($conexion,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                '<?php echo $registros["hora"]; ?>',
            <?php
            }
            ?>
            ]
        },
        yAxis: {
            title: {
                text: 'Cantidad de mensajes'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: ''
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: [
			<?php
			$num_chat = $_COOKIE["TestCookie"];
			$sql = "SELECT nombre from ".$num_chat." GROUP BY nombre";
            $result = mysqli_query($conexion,$sql);
			$cont = mysqli_num_rows($result);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
				{
					name:'<?php echo $registros["nombre"] ?>',
					data: [
				<?php
				$num_chat = $_COOKIE["TestCookie"];
				$sql1 = "SELECT hora, COUNT(*) AS intervencion FROM ".$num_chat." WHERE nombre='".$registros["nombre"]."' GROUP BY hora ORDER BY hora ASC";
				$result1 = mysqli_query($conexion,$sql1);
				while ($registros1= mysqli_fetch_array($result1))
				{
				?>
					<?php echo $registros1["intervencion"] ?>,
				<?php
				}
				?>
				]
				<?php
				if($cont>1){
					$cont--;
					?>
					},
				<?php
				}else{
				?>
				}
				<?php
				}

				?>

            <?php
            }
            ?>


			]
    });
});
		</script>
		<script>
		window.onload = function(){
			var contenedor = document.getElementById('contenedor_carga');
			contenedor.style.visibility='hidden';
			contenedor.style.opacity = '0';
		}
		</script>
</head>
<body>
<script src="js/highcharts.js"></script>
<script src="js/modules/exporting.js"></script>
<!---->
	<div class="topnav">
		<a href="index.html">Inicio</a>
		<a href="instrucciones.php">Instrucciones</a>
        <a class="active" href="#resultados">Resultados</a>
		<a href="contacto.php">Contacto</a>
		<a href="acerca.php">Acera de</a>
	</div>
<!---->
<div id="contenedor_carga">
	<div id="carga"></div>
	</div>
	<!--Contenido de la pagina desde aqui-->
	<div style="padding-left:16px">
		<h2>SAIU</h2>
		<p>Descripcion...</p>
	</div>
<div id="container" style="width:100%; height:400px;"></div>

<script type="text/javascript">
    $(document).ready(function(){
        var options ={
          chart: {
              renderTo: 'container',
              type: 'pie',

          },
          title: {
            text: 'Cantidad de Mensajes por persona'
        },
          yAxis: {
            title: {
                text: 'Fruits Amount'
            }
        },
           series: [{
           }]
        };
        $.getJSON('data.php', function(data){
           options.series[0].data = data;
           var chart = new Highcharts.Chart(options);
        });
    });
</script>
<br><br>
<div class="container_info" role="main">
    	<div class="box_info">
        	<?php
				$num_chat = $_COOKIE["TestCookie"];
				$lineas = file("upload_files/".$num_chat.".txt");
				$palabra = "<Archivo omitido>";
				$cont = 0;
				foreach($lineas as $linea){
			    	if (strstr($linea,$palabra)){
       					//echo "si esta la palabra $linea".'<br>';
						$cont++;
					} else {
						//echo "no esta la palabra".'<br>';
					}
				}
				echo '<strong>Archivos adjuntos: </strong><input type="text" name="cantidad_a" value="'.$cont.'" readonly size ="5"><br></br>';
			?>
            <?php
				$num_chat = $_COOKIE["TestCookie"];
				$sql = $conexion->query("SELECT SUM(num_caracteres) FROM `".$num_chat."`;");
				while($res = mysqli_fetch_array($sql)) {
					echo '<strong>Cantidad de Caracteres: </strong><input type="text" name="cantidad_c" value="'.$res[0].'" readonly size="5"><br></br>';
				}
			?>
            <?php
				$num_chat = $_COOKIE["TestCookie"];
				$sql1 = $conexion->query("SELECT mensaje FROM `".$num_chat."`;");
				$cont_palabras = 0;
				while($res1 = mysqli_fetch_array($sql1)) {
					$pizza = $res1[0];
					$porciones = explode(" ", $pizza);
					$cont_palabras = $cont_palabras + count($porciones);
				}
				echo '<strong>Cantidad de Palabras: </strong><input type="text" name="cantidad_c" value="'.$cont_palabras.'" readonly size="5"><br></br>';
			?>

            <?php
                $num_chat = $_COOKIE["TestCookie"];
                $sql2 = $conexion->query("CREATE TABLE `prototipo3`.`".$num_chat."_emoji` ( `id` INT(11) NOT NULL AUTO_INCREMENT , `caracter` VARCHAR(8) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;");
                //$conexion->query($sql2);
                function str_split_unicode($str, $length = 1) {
                    $tmp = preg_split('~~u', $str, -1, PREG_SPLIT_NO_EMPTY);
                    if ($length > 1) {
                        $chunks = array_chunk($tmp, $length);
                        foreach ($chunks as $i => $chunk) {
                            $chunks[$i] = join('', (array) $chunk);
                        }
                        $tmp = $chunks;
                    }
                    return $tmp;
                }
                $allcontext = "";
                $sql = $conexion->query("SELECT `mensaje` FROM `".$num_chat."`;");
                while($res = mysqli_fetch_array($sql)) {
                    $allcontext = $allcontext." ".$res[0];
                }
                $s = $allcontext;
                $arreglo_cadena = str_split_unicode($s);
                foreach ($arreglo_cadena as $value) {
                    $data = $value;
                    $mb_hex = '';
                    for($i = 0 ; $i<mb_strlen($data,'UTF-8') ; $i++){
                        $c = mb_substr($data,$i,1,'UTF-8');
                        $o = unpack('N',mb_convert_encoding($c,'UCS-4BE','UTF-8'));
                        $mb_hex .= sprintf('%04X',$o[1]);
                    }
                    $conexion->select_db("prototipo3");
                    if((hexdec($mb_hex) >= 126976 && hexdec($mb_hex) <= 127019) ||
                    (hexdec($mb_hex) >= 127312 && hexdec($mb_hex) <= 127404) ||
                    (hexdec($mb_hex) >= 127744 && hexdec($mb_hex) <= 128591) ||
                    (hexdec($mb_hex) >= 128640 && hexdec($mb_hex) <= 128767) ||
                    (hexdec($mb_hex) >= 128896 && hexdec($mb_hex) <= 129535)) {
                        $sql = $conexion->query("INSERT INTO `".$num_chat."_emoji`(`caracter`) VALUES ('".hexdec($mb_hex)."');");
                    }
                }
                $sql = $conexion->query("SELECT `caracter`,COUNT(`caracter`) AS `cantidad` FROM `".$num_chat."_emoji` GROUP BY `caracter` ORDER BY `cantidad` DESC;");
                $cont = 0;
                while($res = mysqli_fetch_array($sql)) {
                    echo '<strong>Cantidad de &#'.$res[0].': </strong><input type="text" name="cantidad_c" value="'.$res[1].'" readonly size="5"><br></br>';
                    $cont++;
                    if($cont == 3) {
                        break;
                    }
                }
                //https://unicode-table.com/es/#tags
            ?>

        	<!--los nombres de las variables para enviar los datos de los input text al php que guarda-->
           	<!--los datos en la base son nombre_usuario y correo-->
        </div>
    </div><br><br>

    <!--Nube de palabras-->
    <h3 align="center">Nube de Palabras</h1><br>
    <div id="myChart"></div>
  	<script>
    var myConfig = {
		type: 'wordcloud',
		options: {
        	text: '<?php
				$num_chat = $_COOKIE["TestCookie"];
				$allcontext = "";
				$sql = $conexion->query("SELECT `mensaje` FROM `".$num_chat."`;");
				while($res = mysqli_fetch_array($sql)) {
					$allcontext = $allcontext." ".$res[0];
				}
				echo $allcontext;
			?>',
        	minLength: 4,
        	ignore: ['establish', 'this', 'omitido>'],
	        stepAngle: 30,
    	    stepRadius: 30,
      	}
    };
    zingchart.render({
	    id: 'myChart',
    	data: myConfig,
		height: 400,
      	width: '100%'
    });
  	</script><br><br><br>

    <!--Diagrama lineal 1-->
    <div id="container2" style="width:100%; height:400px;"></div>


<script type="text/javascript">
    $(document).ready(function(){
        var options ={
          chart: {
              renderTo: 'container2',
              type: 'line',

          },
          title: {
            text: 'Cantidad de Mensajes por persona'
        },
		xAxis: {
            categories: [<?php
			$num_chat = $_COOKIE["TestCookie"];
            $sql = "SELECT `fecha` FROM `".$num_chat."` GROUP BY `fecha` ";
            $result = mysqli_query($conexion,$sql);
            while ($registros = mysqli_fetch_array($result))
            {
            ?>
                '<?php echo $registros[0]; ?>',
            <?php
            }
            ?>]
        },
          yAxis: {
            title: {
                text: 'Cantidad de Mensajes'
            }
        },
           series: [{
           }]
        };
        $.getJSON('data2.php', function(data){
           options.series[0].data = data;
           var chart = new Highcharts.Chart(options);
        });
    });
</script>









<br><br>

<div id="container5" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div id="container6" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div class="container_info" role="main">
	<footer>
		<p><strong>Universidad de las Fuerzas Armadas ESPE.</strong></p>
	</footer>
</div>

</body>
</html>
